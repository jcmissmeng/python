#while for
# condition = True
counter = 1
# 最适合使用while的是递归！

while counter <= 10 :
    counter += 1
    print(counter)  
else:
    print('EOF')