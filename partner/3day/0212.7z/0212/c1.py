# 函数 1.功能性 2.隐藏细节3.避免编写重复的代码
#1\round函数   round(a参数，b小数点位数自动四舍五入)

""" a = 1.2386
result = round(a,2)
print(result) """

# 要求：
# 1.实现两个数字的相加
# 2.打印输入的参数


def add(x,y):
    result = x + y
    return result

def print_code(code):
    print(code)
 
a = add(1,2)
b = print('Python')
print(a,b)


